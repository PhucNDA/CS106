Use main.py to solve the problem

Because of memory limitation, please clone the git to the "Dataset" folder "https://github.com/likr/kplib"

It's currently empty

Author: Nguyen Duc Anh Phuc

